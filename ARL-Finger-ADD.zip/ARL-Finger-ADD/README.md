# ARL-Finger-ADD

- 批量添加指纹`ARL(最新版)`
- 指纹`Ehole3.0`自带的指纹文件
- 简单实现，能用就行!

### Usage:

```
usage:
         python3 ARl-Finger-ADD.py https://192.168.1.1:5003/ admin password
```

![image](./0.png)

![image](./1.png)

![image](./2.png)
